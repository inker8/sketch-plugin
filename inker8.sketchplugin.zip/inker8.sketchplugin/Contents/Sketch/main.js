var that = this;
function __skpm_run (key, context) {
  that.context = context;

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/main.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/main.js":
/*!*********************!*\
  !*** ./src/main.js ***!
  \*********************/
/*! exports provided: exportSelected, exportPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "exportSelected", function() { return exportSelected; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "exportPage", function() { return exportPage; });
// ## Sketch 插件开发
// http://bang590.github.io/JSPatchConvertor/
// https://github.com/skpm/skpm/issues/106#issuecomment-355958851
// https://medium.com/sketch-app-sources/sketch-plugin-snippets-for-plugin-developers-e9e1d2ab6827
var writeTextToFile = function writeTextToFile(text, filePath) {
  // var t = [NSString stringWithFormat:@"%@", text],
  var t = NSString.stringWithFormat("%@", text);
  var f = NSString.stringWithFormat('%@', filePath); // f = [NSString stringWithFormat:@"%@", filePath];

  return t.writeToFile_atomically_encoding_error(f, true, NSUTF8StringEncoding, null); // return [t writeToFile:f atomically:true encoding:NSUTF8StringEncoding error:nil];
};

var readTextFromFile = function readTextFromFile(filePath) {
  console.log('filePath', filePath);
  return String(NSString.stringWithContentsOfFile_encoding_error(filePath, NSUTF8StringEncoding, null));
}; // var jsonFromFile = function(filePath, mutable) {
//   var data = [NSData dataWithContentsOfFile:filePath];
// var options = mutable == true ? NSJSONReadingMutableContainers : 0
// return [NSJSONSerialization JSONObjectWithData:data options:options error:nil];
// }
// var saveJsonToFile = function(jsonObj, filePath) {
//   writeTextToFile(stringify(jsonObj), filePath);
// }
// var stringify = function(obj, prettyPrinted) {
//   var prettySetting = prettyPrinted ? NSJSONWritingPrettyPrinted : 0,
//   jsonData = [NSJSONSerialization dataWithJSONObject:obj options:prettySetting error:nil];
//   return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
// }


var createTempFolderNamed = function createTempFolderNamed(name) {
  var tempPath = getTempFolderPath(name);
  createFolderAtPath(tempPath);
  return tempPath;
};

var getTempFolderPath = function getTempFolderPath(withName) {
  var cachesURL = NSTemporaryDirectory();
  withName = typeof withName !== 'undefined' ? withName : Date.now() / 1000;
  var name = cachesURL + '/' + withName;
  console.log('temp', name);
  return name;
};

var createFolderAtPath = function createFolderAtPath(pathString) {
  var fileManager = NSFileManager.defaultManager();
  if (fileManager.fileExistsAtPath(pathString)) return true;
  return fileManager.createDirectoryAtPath_withIntermediateDirectories_attributes_error(pathString, true, null, null);
};

var removeFileOrFolder = function removeFileOrFolder(filePath) {
  NSFileManager.defaultManager().removeItemAtPath_error(filePath, null);
}; // function readFile(path) {
//   // var path = "/Users/z/Projects/Node/Hydux/inker8/packages/client/src/test/fixtures/xd/shadow.svg"
//   var str = NSString.stringWithContentsOfFile_encoding_error(path, NSUTF8StringEncoding, null);
//   return str
// }


function getDbJson(layers) {
  var tempFolder = createTempFolderNamed();

  var DOM = __webpack_require__(/*! sketch/dom */ "sketch/dom");

  DOM.export(layers, {
    formats: 'svg',
    output: tempFolder,
    compact: true
  });
  var svgList = layers.map(function (l) {
    return {
      svg: readTextFromFile(tempFolder + '/' + l.name + '.svg'),
      name: l.name
    };
  }).filter(function (s) {
    return s.svg && s.svg !== 'null' && s.name;
  });
  return "\n    window['__ARTBOARDS__'] = ".concat(JSON.stringify(svgList), "\n  ");
}

function getSavePath(name) {
  var _ = function _(f) {
    return f;
  };

  var savePanel = NSSavePanel.savePanel();
  savePanel.setTitle(_("Export spec"));
  savePanel.setNameFieldLabel(_("Export to:"));
  savePanel.setPrompt(_("Export"));
  savePanel.setCanCreateDirectories(true);
  savePanel.setShowsTagField(false); // savePanel.setAllowedFileTypes(NSArray.arrayWithObject("json"));

  savePanel.setAllowsOtherFileTypes(false);
  savePanel.setNameFieldStringValue(name);

  if (savePanel.runModal() != NSOKButton) {
    return false;
  }

  var savePath = savePanel.URL().path().stringByDeletingLastPathComponent(),
      fileName = savePanel.URL().path().lastPathComponent();
  savePath = savePath + '/' + fileName.replace(/\s/g, '_'); // savePath = savePath[0] === '/' ? savePath : '/' + savePath

  return savePath;
}

function getPluginTemplatePath() {
  return context.scriptPath.split(/\/|\\/g).slice(0, -2).concat('Resources/static-plugin').join('/');
}

function copy(src, dist) {
  console.log('cp', src, dist);
  var fileManager = NSFileManager.defaultManager();
  fileManager.copyItemAtPath_toPath_error(src, dist, null);
}

function exportLayers(name, layers) {
  var dbjs = getDbJson(layers);
  console.log('dbjs', dbjs);
  var tplPath = getPluginTemplatePath();
  var savePath = getSavePath(name);

  if (!savePath) {
    return;
  }

  var fileManager = NSFileManager.defaultManager();

  if (fileManager.fileExistsAtPath(savePath)) {
    removeFileOrFolder(savePath);
    console.log('removed', savePath);
  }

  copy(tplPath, savePath);
  writeTextToFile(dbjs, savePath + '/dist/db.js');
}

var context = null;

function getDocName() {
  var filePath = context.document.fileURL() ? context.document.fileURL().path().stringByDeletingLastPathComponent() : "~";
  var fileName = context.document.displayName().stringByDeletingPathExtension();
  return fileName;
}

function exportSelected(ctx) {
  context = ctx;

  var sketch = __webpack_require__(/*! sketch */ "sketch");

  var document = sketch.getSelectedDocument();
  exportLayers(getDocName(), document.selectedLayers.layers);
}
function exportPage(ctx) {
  context = ctx;

  var sketch = __webpack_require__(/*! sketch */ "sketch");

  var document = sketch.getSelectedDocument();
  var page = document.pages.filter(function (p) {
    return p.selected;
  })[0];
  exportLayers(getDocName(), page.layers);
}

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ })

/******/ });
  if (key === 'default' && typeof exports === 'function') {
    exports(context);
  } else {
    exports[key](context);
  }
}
that['exportSelected'] = __skpm_run.bind(this, 'exportSelected');
that['onRun'] = __skpm_run.bind(this, 'default');
that['exportPage'] = __skpm_run.bind(this, 'exportPage')

//# sourceMappingURL=main.js.map